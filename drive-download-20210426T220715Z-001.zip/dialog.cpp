#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_report_clicked()
{
    QString enteredId = ui->lineEdit_memberId->text();

    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC3");
    db.setHostName("127.0.0.1");
    db.setUserName("root");
    db.setPassword("1234");
    db.setDatabaseName("Database");
    db.open();

    QSqlQuery query;
    query.exec(" ")

    if(enteredId = )
}
